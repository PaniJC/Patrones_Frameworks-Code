﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod
{
    public class Cerveza : Bebida
    {
        public override int CuantomeEmbriaga()
        {
            return 200;
        }
    }
}
