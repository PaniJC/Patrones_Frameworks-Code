﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod
{
    public class Creador
    {
        public const int VINO = 1;
        public const int CERVEZA = 2;


        public static  Bebida _creador(int Tipo)
        {
            switch (Tipo)
            {
                case VINO:
                    return new Vino();
                case CERVEZA:
                    return new Cerveza();
                default:
                    return null;
            }
        }

    }
}
