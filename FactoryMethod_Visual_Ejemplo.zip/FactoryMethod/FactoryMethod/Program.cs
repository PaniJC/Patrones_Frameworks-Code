﻿using System;

namespace FactoryMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            Bebida _Bebida = Creador._creador(Creador.CERVEZA);
            Console.WriteLine(_Bebida.CuantomeEmbriaga()); 
        }
    }
}
