﻿using System;

namespace FactoryMethod_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona _persona = FactorySalarios._FactorySalorios(tipoEmpleado.operario);
            Console.WriteLine("Salario : " + _persona.CalcularSalario(55));
            Console.ReadLine();
           
        }
    }
}
