﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod_2
{
    public enum tipoEmpleado
    {
        operario,
        coordinador
    }
}
