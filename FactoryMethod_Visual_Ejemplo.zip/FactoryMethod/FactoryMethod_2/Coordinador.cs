﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod_2
{
    public class Coordinador : Persona
    {
        public override double CalcularSalario(int horasLaboradas)
        {
            return 2000 * horasLaboradas;
        }
    }
}
