﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod_2
{
   public abstract class Persona
    {
        public abstract double CalcularSalario(int horasLaboradas);
    }
}
