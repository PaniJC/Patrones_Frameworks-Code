﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod_2
{
   public class FactorySalarios
    {

        public static  Persona _FactorySalorios(tipoEmpleado _Tipo)
        {
            switch(_Tipo)
            {
                case tipoEmpleado.operario:
                    return new Operario();
                case tipoEmpleado.coordinador:
                    return new Coordinador();
                default:
                    return null;
            }
        }
    }
}
