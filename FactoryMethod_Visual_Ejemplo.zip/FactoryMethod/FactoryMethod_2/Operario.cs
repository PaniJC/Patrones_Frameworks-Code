﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethod_2
{
   public class Operario : Persona
    {
        public override double CalcularSalario(int horasLaboradas)
        {
            return 1000 * horasLaboradas;
        }
    }
}
