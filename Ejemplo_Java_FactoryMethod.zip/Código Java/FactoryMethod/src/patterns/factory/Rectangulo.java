/**
 *
 * @author Elmer Marin Traslaviña, Juan Camilo Paniagua Alvarez
 */
//Package donde van todas las clases del ejemplo
package patterns.factory;

// Creamos una clase implementando la interface Forma
public class Rectangulo implements Forma {
    
    /*Sobreescribimos el método dibujar, el cual imprime un mensaje dependiendo
    de la forma*/
    @Override
    public void dibujar(){
        System.out.println("Hola, soy un Rectángulo");
    }
    
}