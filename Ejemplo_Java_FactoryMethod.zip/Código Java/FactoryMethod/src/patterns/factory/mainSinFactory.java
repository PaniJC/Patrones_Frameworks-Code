/**
 *
 * @author Elmer Marin Traslaviña, Juan Camilo Paniagua Alvarez
 */
//Package donde van todas las clases del ejemplo
package patterns.factory;

//Definimos la clase principal.
public class mainSinFactory {
    
    /*Definimos el método principal SIN USAR FACTORY, para mirar como quedaría
    instanciar desde la misma clase, las definidas desde la implementación de
    la interface Forma.*/
    public static void main(String[] args){
        mainSinFactory sinFactory = new mainSinFactory();
        sinFactory.imprimirForma("CUADRADO");
    }
    
    /*Sin crear una Factory sería así. Este es un método que no retorna valor y
    con el cual dependiendo del tipo de figura sugerida, la instanciamos.*/
    public void imprimirForma(String TipoForma) {
        /*Creamos el objeto figura desde la interface. Luego nos toca desde
        el mismo método de la clase principal, definir cuál forma aplicará
        para posteriormente instanciar el objeto como un nuevo elemento de 
        alguna de las clases previamente creadas (Rectanguo, Cuadrado y Circ*/
        Forma figura;
        switch (TipoForma) {
            case "CIRCULO":
                figura = new Circulo();
                break;
            case "RECTANGULO":
                figura = new Rectangulo();
                break;
            case "CUADRADO":
                figura = new Cuadrado();
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + TipoForma);
        }
        
        figura.dibujar();

    }
}
