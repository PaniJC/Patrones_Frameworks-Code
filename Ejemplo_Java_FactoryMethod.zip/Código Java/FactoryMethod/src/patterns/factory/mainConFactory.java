/**
 *
 * @author Elmer Marin Traslaviña, Juan Camilo Paniagua Alvarez
 */
//Package donde van todas las clases del ejemplo
package patterns.factory;


public class mainConFactory {
    
    /*Definimos el método principal desde el cual instanciaremos la propia
    clase, para llamar desde esta el método del Factory */
    public static void main(String[] args){
        mainConFactory conFactory = new mainConFactory();
        conFactory.imprimirForma("CUADRADO");
    }
    
    //Usando Factory sería así el método imprimirForma.
    public void imprimirForma(String forma){
        Forma figura = FactoryForma.obtenerForma(forma);
        figura.dibujar();   
    }
    
}
