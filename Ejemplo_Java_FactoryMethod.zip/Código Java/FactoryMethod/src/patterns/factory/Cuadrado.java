/**
 *
 * @author PaniJC
 */
package patterns.factory;

public class Cuadrado implements Forma {
    
    @Override
    public void dibujar(){
        System.out.println("Hola, soy un Cuadrado");
    }
    
}