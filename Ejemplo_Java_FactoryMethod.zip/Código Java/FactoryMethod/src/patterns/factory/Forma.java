/**
 *
 * @author Elmer Marin Traslaviña, Juan Camilo Paniagua Alvarez
 */
//Package donde van todas las clases del ejemplo
package patterns.factory;

//Definimos la interface Forma con un método dibujar.
public interface Forma {
    void dibujar();
}

