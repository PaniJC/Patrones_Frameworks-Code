/**
 *
 * @author Elmer Marin Traslaviña, Juan Camilo Paniagua Alvarez
 */
//Package donde van todas las clases del ejemplo
package patterns.factory;

//Creamos la clase Factory
public class FactoryForma {
    
    //Definimos un método para obetener la forma a partir de un tipo (argumento)
    public static Forma obtenerForma(String TipoForma){
        if(TipoForma == null){
            return null;
        }
        
        /*Dependiendo del argumento, instanciamos a través del Factory la clase
        que aplique*/
        if(TipoForma.equalsIgnoreCase("CIRCULO")){
            return new Circulo();
        }else if(TipoForma.equalsIgnoreCase("RECTANGULO")) {
            return new Rectangulo();
        }else if(TipoForma.equalsIgnoreCase("CUADRADO")){
            return new Cuadrado();
        }else{
            throw new IllegalStateException("Figura no identificada " + 
                    TipoForma);
        }
    }
    
}
